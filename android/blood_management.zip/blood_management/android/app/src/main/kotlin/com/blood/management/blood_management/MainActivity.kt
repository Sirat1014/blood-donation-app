package com.blood.management.blood_management

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
